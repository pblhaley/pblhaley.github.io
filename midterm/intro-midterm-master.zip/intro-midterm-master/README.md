# intro-midterm

Using all that you have studied so far in class, build the site below. We have provided you an index.html file and a style.css file. All the images you will need are in the img folder.

Once you're finished, please publish your site to your github.io page (where you put your homework). You have until 7:00 to have your site uploaded. Your site doesn't have to be perfect, but we want to see what you can do in 30 minutes.

<img src="https://docs.google.com/drawings/d/1MkKUyJVuSL3EaN-SH0dQJDVQ_HlWLELrDHUoMOxz_b4/pub?w=1443&amp;h=1485">



